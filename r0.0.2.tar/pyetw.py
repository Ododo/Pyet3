import traceback

import pyet
from etConstants import *
from collections import defaultdict

def PyetPrint(text):
    print (
"""
**********
::Pyetw.py::

 %s
**********
"""%text ) 



class RunTime:
    loaded_addons = defaultdict(dict)
runtime = RunTime()

class Addon(object):
    name="Main"
    group="pyetw"
    
    def __init__(self):
        self.call = pyet.EtCaller()
        self.tools = pyet.EtTools()
        runtime.loaded_addons[self.group][self.name] = self

    def unload(self):
        pass

    def GameConsoleCommand(self):
        pass

    def GameInit(self, leveltime, randomSeed, restart):
        pass

    def GameShutdown(self):
        pass

    def ClientConnect(self, client, firstTime, isBot):
        pass

    def ClientBegin(self, client):
        pass

    def ClientUserInfoChanged(self, client):
        pass

    def ClientDisconnect(self, client):
        pass

    def ClientCommand(self, client):
        pass

    def ClientThink(self, client):
        pass

    def GameRunFrame(self, leveltime):
        pass
    
try:
    import addons
except (ImportError, SyntaxError):
    PyetPrint(traceback.format_exc())

############

def Wrapper(*args):
    """
    Et Callbacks
    """
    cmd = args[0]
    f = ""
    if cmd == GAME_INIT:
        f = "GameInit"
        tpl= args[0:3]
        runtime.init = 0

    elif cmd == GAME_SHUTDOWN:
        f = "GameShutdown"
        tpl = ()
    elif cmd == GAME_CLIENT_CONNECT:
        f = "ClientConnect"
        tpl = args[0:3]
    elif cmd == GAME_CLIENT_BEGIN:
        f = "ClientBegin"
        tpl = args[1],
    elif cmd == GAME_CLIENT_USERINFO_CHANGED:
       f = "ClientUserInfoChanged"
       tpl = args[1],
    elif cmd == GAME_CLIENT_DISCONNECT:
        f = "ClientDisconnect"
        tpl = args[1],
    elif cmd == GAME_CLIENT_COMMAND:
        f = "ClientCommand"
        tpl = args[1],
    elif cmd == GAME_CLIENT_THINK:
        f = "ClientThink"
        tpl = args[1],
    elif cmd == GAME_RUN_FRAME:
        f = "GameRunFrame"
        tpl = args[1],
    elif cmd == GAME_CONSOLE_COMMAND:
        f = "GameConsoleCommand"
        tpl = ()

    if f:
        for g in runtime.loaded_addons.values():
            for a in g.values():
                getattr(a, f)(*tpl)

#################












